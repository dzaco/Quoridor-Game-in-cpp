#pragma once
#include "stdafx.h"
#include "plansza.h"
#include "gracz.h"
#include "czlowiek.h"
#include "komputer.h"
#include "gra.h"

#include <string>
#include <windows.h>
#include <fstream>
#include <iostream>
#include <cstdlib>
using namespace std;


/*
TODO

FindPlayer() wyszukuje w pliku "gracz1" 
co w przypadku gdy gra dwoje ludzi???


metode void Update( gracz &p1, gracz &p2);	
mozna zmienic na void Update( gracz &wsk );			
wykorzystujac pole IsFirstPlayer;




*/